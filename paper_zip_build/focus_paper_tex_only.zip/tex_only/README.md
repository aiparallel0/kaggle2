# FOCUS paper — Overleaf preview (tex-only)

This zip contains **only the LaTeX sources**, no figures and no data files.
It compiles on Overleaf out of the box because every `\includegraphics`
is wrapped in `\usepackage[draft]{graphicx}` — figures render as empty
placeholder rectangles of the correct size, so you can preview the
**page layout, figure placement, and text density** before committing
to the full build.

## Quick start (Overleaf)
1. New Project → Upload Project → drop in `focus_paper_tex_only.zip`.
2. Set the main file to `paper_visual.tex`.
3. Click **Recompile**. You will see boxes where figures will go.
4. (Optional) Compile `presentation/slides.tex` for the beamer deck.

## Switch from preview to real build
Once you are happy with the layout:
1. Generate figures locally:
   `python3 scripts/build_visuals.py` (in the main repo)
2. Upload the resulting `results/figures/*.pdf` to Overleaf.
3. In `paper_visual.tex` and `presentation/slides.tex`, change
   `\usepackage[draft]{graphicx}` → `\usepackage{graphicx}`.

## Files
```
paper_visual.tex                   IEEE-conference paper (figure-led)
report/template.tex                Original template (reference)
report/references.bib              Citations
report/sections/diagrams_focus.tex TikZ algorithmic diagrams
report/sections/explainer_basics.tex  Basics→advanced sidebar
presentation/slides.tex            Beamer 16:9 deck
```

## What's NOT in this zip (intentionally)
- `results/figures/*.pdf` — 12 generated figures (~1.3 MB)
- `results/*.json` — real-data fixtures
- `scripts/build_visuals.py` — figure regenerator

To get the full bundle, run `bash scripts/build_paper_zip.sh` in the
main repo — that produces `focus_paper_visuals.zip` (1.3 MB, 42 files).
